const { test, expect } = require('@playwright/test');
const testData = require('../../utils/testdata.json');

test.describe('Login API Tests', () => {

    test('Valid Login API', async ({ request }) => {

        const response = await request.post(
            'https://rahulshettyacademy.com/api/ecom/auth/login',
            {
                data: 
                {
                    userEmail: testData.validLogin.username,
                    userPassword: testData.validLogin.password
                }
            }
        );

        // HTTP status validation
        expect(response.status()).toBe(200);

        // Response body
        const responseBody = await response.json();

        console.log('Login response:', responseBody);

        // Validate response
        expect(responseBody.message).toBe('Login Successfully');

        // Validate token
        expect(responseBody.token).toBeTruthy();

        // Validate user information
        expect(responseBody.userId).toBeTruthy();
    });
});